# djselect2
Ejemplo de Django sobre filtro en una relación FK
