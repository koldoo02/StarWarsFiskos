from django.apps import AppConfig


class MuseoConfig(AppConfig):
    name = 'museo'
